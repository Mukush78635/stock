﻿using Newtonsoft.Json.Linq;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Threading.Tasks;
using System.Web;
using System.Web.Mvc;
using System.Web.Script.Serialization;
using System.Xml.Linq;
using WebApplication2.Models;

namespace WebApplication2.Controllers
{
    public class HomeController : Controller
    {
        public ActionResult Index()
        {
            ViewBag.CompanyList = new CompanyStock().GetCompanies().ToList();
            CompanyStock obj = new CompanyStock();
            var cData = obj.GetUserCompanyview();
            var code = string.Join(",", cData.Select(r => r.CompanyCode).ToList());
            if (code != null)
            {

              var Company = getData(code);
                

                var ddr = Company.Select(x => { x.Latestdatetime = obj.convertdate(x.closeTime).ToString(); return x; }).ToList();

                ViewBag.CompanyStock = ddr;
                ViewBag.Company= ddr.FirstOrDefault();
            }
           
            //ViewBag.CompanyName= CompanyStockData.companyName;
            //ViewBag.LatestPrice = CompanyStockData.latestPrice;
            return View();
        }
        [HttpPost]
        public ActionResult Index(CompanyStock companystock)
        {
            CompanyStock obj = new CompanyStock();
            var cData=obj.AddEditUserCompanyview(companystock);      
            return RedirectToAction("Index");
        }

        public ActionResult Contact()
        {
            return View();
        }

        public PartialViewResult WhatchlistView()
        {
            CompanyStock obj = new CompanyStock();
            var cData = obj.GetUserCompanyview();
            var code = string.Join(",", cData.Select(r => r.CompanyCode).ToList());
            if (code != null)
            {

                var Company = getData(code);


                var ddr = Company.Select(x => { x.Latestdatetime = obj.convertdate(x.closeTime).ToString(); return x; }).ToList();

                ViewBag.CompanyStock = ddr;
               
            }

            return PartialView();
        }

   
        public List<CompanyStockResponseModel> getData(string symbol)
        {
            List<CompanyStockResponseModel> list = new List<CompanyStockResponseModel>();

            //var IEXTrading_API_PATH = "https://www.alphavantage.co/query?function=TIME_SERIES_INTRADAY&symbol=MSFT&interval=60min&apikey=GCVHKLLX3CBGO4B6";
            var IEXTrading_API_PATH = string.Format("https://api.iextrading.com/1.0/stock/market/batch?symbols={0}&types=quote", string.Join(",", symbol));

            IEXTrading_API_PATH = string.Format(IEXTrading_API_PATH, symbol);

            using (HttpClient client = new HttpClient())
            {
                client.DefaultRequestHeaders.Accept.Clear();
                client.DefaultRequestHeaders.Accept.Add(new System.Net.Http.Headers.MediaTypeWithQualityHeaderValue("application/json"));

                //For IP-API
                client.BaseAddress = new Uri(IEXTrading_API_PATH);
                HttpResponseMessage response = client.GetAsync(IEXTrading_API_PATH).GetAwaiter().GetResult();
                if (response.IsSuccessStatusCode)
                {
                    using (HttpContent content = response.Content)
                    {
                        // ... Read the string.
                        Task<string> result = content.ReadAsStringAsync();
                        string res = result.Result;
                        //  var r = new JavaScriptSerializer().Deserialize<string>(res);
                        JavaScriptSerializer serializer = new JavaScriptSerializer();
                        dynamic item = serializer.Deserialize<object>(res);

                      //  var dd = item["Time Series (Daily)"];

                        foreach (var it in item)
                        {
                            var aa = it.Key;
                            var bb = it.Value;                 
                            CompanyStockResponseModel com = new CompanyStockResponseModel();
                            foreach (var data in bb)
                            {
                                
                                    com.symbol = data.Value["symbol"].ToString();
                                    com.companyName = data.Value["companyName"].ToString();
                                    com.primaryExchange = data.Value["primaryExchange"].ToString();
                                    com.sector = data.Value["sector"]?.ToString();
                                    com.calculationPrice = data.Value["calculationPrice"]?.ToString();
                                    com.open = data.Value["open"]?.ToString();
                                    com.openTime = Convert.ToInt64(data.Value["openTime"]?.ToString());
                                       com.close = data.Value["close"].ToString();
                                    com.closeTime = Convert.ToInt64(data.Value["closeTime"]?.ToString());
                                    com.high = data.Value["high"]?.ToString();
                                    com.low = data.Value["low"]?.ToString();
                                    com.latestPrice = data.Value["latestPrice"]?.ToString();
                                    com.latestSource = data.Value["latestSource"]?.ToString();
                                    com.latestTime = data.Value["latestTime"]?.ToString();
                                    com.latestUpdate = Convert.ToInt64(data.Value["latestUpdate"]?.ToString());
                                    com.latestVolume = data.Value["latestVolume"]?.ToString();
                                    com.iexRealtimePrice = data.Value["iexRealtimePrice"]?.ToString();
                                    com.iexRealtimeSize = data.Value["iexRealtimeSize"]?.ToString();
                                    com.iexLastUpdated = data.Value["iexLastUpdated"]?.ToString();
                                    com.delayedPrice = data.Value["delayedPrice"]?.ToString();
                                    com.delayedPriceTime = Convert.ToInt64(data.Value["delayedPriceTime"]?.ToString());
                                    com.extendedPrice = data.Value["extendedPrice"]?.ToString();
                                    com.extendedChange = data.Value["extendedChange"]?.ToString();
                                    com.extendedChangePercent = data.Value["extendedChangePercent"]?.ToString();
                                    com.extendedPriceTime = Convert.ToInt64(data.Value["extendedPriceTime"]?.ToString());
                                    com.previousClose = data.Value["previousClose"]?.ToString();
                                    com.change = data.Value["change"]?.ToString();
                                    com.changePercent = data.Value["changePercent"]?.ToString();
                                    com.iexMarketPercent = data.Value["iexMarketPercent"]?.ToString();
                                    com.iexVolume = data.Value["iexVolume"]?.ToString();
                                    com.avgTotalVolume = data.Value["avgTotalVolume"]?.ToString();
                                    com.iexBidPrice = data.Value["iexBidPrice"]?.ToString();
                                    com.iexBidSize = data.Value["iexBidSize"]?.ToString();
                                    com.iexAskPrice = data.Value["iexAskPrice"]?.ToString();
                                    com.iexAskSize = data.Value["iexAskSize"]?.ToString();
                                    com.marketCap = data.Value["marketCap"]?.ToString();                              
                                   com.peRatio = data.Value?["peRatio"]?.ToString(); 
                                    com.week52High = data.Value["week52High"]?.ToString();
                                    com.week52Low = data.Value["week52Low"]?.ToString();
                                    com.ytdChange = data.Value["ytdChange"]?.ToString();
                                    com.startChar = com.companyName.Substring(0, 1).ToUpper();                               
                                list.Add(com);
                               // }
                            }
                        }


                    }
                }
                //Console.ReadLine();
            }
            return list;
        }
        
        [HttpPost]
        public JsonResult fillchart(string code)
        {

            if (code != null)
            {
                var compnaylist = getApiresponserperday(code);
                var compnaydetail = getApiresponser(code, compnaylist);
                var comm = compnaydetail.Select(r => { r.AveragePrice = ((r.high + r.low) / 2); return r; }).ToList();
                comm = comm.OrderByDescending(x => x.date).ToList();
                return Json(comm, JsonRequestBehavior.AllowGet);
            }
            return Json("", JsonRequestBehavior.AllowGet);
        }
        [HttpPost]
        public JsonResult fillchart2(string code)
        {

            if (code != null)
            {
                var Company = getData(code);
              
                var comm = Company.FirstOrDefault();

                return Json(comm, JsonRequestBehavior.AllowGet);
            }
            return Json("", JsonRequestBehavior.AllowGet);
        }

        public List<CompanyStockHistoricalData> getApiresponser(string symbol, List<CompanyStockHistoricalData> list)
        {

           // List<CompanyStockHistoricalData> list = new List<CompanyStockHistoricalData>();



            var IEXTrading_API_PATH = "https://www.alphavantage.co/query?function=TIME_SERIES_DAILY_ADJUSTED&symbol=" + symbol + "&apikey=GCVHKLLX3CBGO4B6";

            IEXTrading_API_PATH = string.Format(IEXTrading_API_PATH, symbol);

            using (HttpClient client = new HttpClient())
            {
                client.DefaultRequestHeaders.Accept.Clear();
                client.DefaultRequestHeaders.Accept.Add(new System.Net.Http.Headers.MediaTypeWithQualityHeaderValue("application/json"));

                //For IP-API
                client.BaseAddress = new Uri(IEXTrading_API_PATH);
                HttpResponseMessage response = client.GetAsync(IEXTrading_API_PATH).GetAwaiter().GetResult();
                if (response.IsSuccessStatusCode)
                {
                    using (HttpContent content = response.Content)
                    {
                        // ... Read the string.
                        Task<string> result = content.ReadAsStringAsync();
                        string res = result.Result;
                        //  var r = new JavaScriptSerializer().Deserialize<string>(res);
                        JavaScriptSerializer serializer = new JavaScriptSerializer();
                        dynamic item = serializer.Deserialize<object>(res);

                        //dynamic item2 = JsonConvert.DeserializeObject(item);
                        dynamic stuff = JObject.Parse(res);
                        //var ss = item[0];
                        try
                        {
                            var dd = item["Time Series (Daily)"];

                            foreach (var it in dd)
                            {
                                var aa = it.Key;
                                var bb = it.Value;
                                CompanyStockHistoricalData com = new CompanyStockHistoricalData();
                                com.date = Convert.ToDateTime(aa);
                                com.open = Convert.ToDouble(bb["1. open"]);
                                com.high = Convert.ToDouble(bb["2. high"]);
                                com.low = Convert.ToDouble(bb["3. low"]);
                                com.close = Convert.ToDouble(bb["4. close"]);
                                // com.companyCode = item["Meta Data"]["2. Symbol"];
                                list.Add(com);
                            }
                        }
                        catch(Exception e)
                        {

                        }


                    }

                }

            }
            return list;
        }

        public List<CompanyStockHistoricalData> getApiresponserperday(string symbol)
        {

            List<CompanyStockHistoricalData> list = new List<CompanyStockHistoricalData>();

            var IEXTrading_API_PATH = "https://www.alphavantage.co/query?function=TIME_SERIES_INTRADAY&symbol="+symbol+"&interval=5min&apikey=GCVHKLLX3CBGO4B6";

           // var IEXTrading_API_PATH = "https://www.alphavantage.co/query?function=TIME_SERIES_INTRADAY&symbol=" + symbol + "&apikey=GCVHKLLX3CBGO4B6";

            IEXTrading_API_PATH = string.Format(IEXTrading_API_PATH, symbol);

            using (HttpClient client = new HttpClient())
            {
                client.DefaultRequestHeaders.Accept.Clear();
                client.DefaultRequestHeaders.Accept.Add(new System.Net.Http.Headers.MediaTypeWithQualityHeaderValue("application/json"));

                //For IP-API
                client.BaseAddress = new Uri(IEXTrading_API_PATH);
                HttpResponseMessage response = client.GetAsync(IEXTrading_API_PATH).GetAwaiter().GetResult();
                if (response.IsSuccessStatusCode)
                {
                    using (HttpContent content = response.Content)
                    {
                        // ... Read the string.
                        Task<string> result = content.ReadAsStringAsync();
                        string res = result.Result;
                        //  var r = new JavaScriptSerializer().Deserialize<string>(res);
                        JavaScriptSerializer serializer = new JavaScriptSerializer();
                        dynamic item = serializer.Deserialize<object>(res);

                        //dynamic item2 = JsonConvert.DeserializeObject(item);
                        dynamic stuff = JObject.Parse(res);
                        //var ss = item[0];
                        try
                        {
                            var dd = item["Time Series (5min)"];

                            foreach (var it in dd)
                            {
                                var aa = it.Key;
                                var bb = it.Value;
                                CompanyStockHistoricalData com = new CompanyStockHistoricalData();
                                com.date = Convert.ToDateTime(aa);
                                com.open = Convert.ToDouble(bb["1. open"]);
                                com.high = Convert.ToDouble(bb["2. high"]);
                                com.low = Convert.ToDouble(bb["3. low"]);
                                com.close = Convert.ToDouble(bb["4. close"]);
                                // com.companyCode = item["Meta Data"]["2. Symbol"];
                                list.Add(com);
                            }
                        }
                        catch (Exception e)
                        {

                        }


                    }

                }

            }
            return list;
        }

        public ActionResult About()
        { 
            long unixDate = 1554321606730;
            DateTime now = DateTime.Now;
            long t = now.ToFileTime();
            var s = 1554408193834;
            s = 1554408193834;
            var ss = 131989315649948978;
            DateTime today = new DateTime(t);

            return View();
        }
       
    }
}