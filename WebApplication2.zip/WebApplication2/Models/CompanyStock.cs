﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data;
using System.Data.SqlClient;
using Dapper;
using System.Web.Configuration;
using System.Web.Mvc;
using System.ComponentModel.DataAnnotations;

namespace WebApplication2.Models
{
    public class CompanyStock
    {
        public int Id { get; set; }
        [Required(ErrorMessage = "Stock is required")]
        public int CompanyId { get; set; }
        public string CompanyCode { get; set; }

        public string CompanyName { get; set; }

        public List<SelectListItem> GetCompanies()
        {
            using (IDbConnection conn = new SqlConnection(WebConfigurationManager.ConnectionStrings["dbCon"].ConnectionString))
            {
                var result = conn.Query<SelectListItem>("select Id as Value,CompanyName as Text from  tbl_CompanyStock ", commandType: CommandType.Text).ToList();
                return result;
            }

        }

        public List<CompanyStock> AddEditUserCompanyview(CompanyStock companystock)
        {
            using (IDbConnection conn = new SqlConnection(WebConfigurationManager.ConnectionStrings["dbCon"].ConnectionString))
            {
                return conn.Query<CompanyStock>("Usp_AddEditCompany", new
                {
                    @Action = "Add",
                    @CompanyId = companystock.CompanyId,
                    @CompanyCode = companystock.CompanyCode
                }, commandType: CommandType.StoredProcedure).ToList();
            }

        }
        public List<CompanyStock> GetUserCompanyview()
        {
            using (IDbConnection conn = new SqlConnection(WebConfigurationManager.ConnectionStrings["dbCon"].ConnectionString))
            {
                return conn.Query<CompanyStock>("Usp_AddEditCompany",  commandType: CommandType.StoredProcedure).ToList();
            }

        }
     
        public void DeleteUserCompanyview(CompanyStock companystock)
        {
            using (IDbConnection conn = new SqlConnection(WebConfigurationManager.ConnectionStrings["dbCon"].ConnectionString))
            {
                conn.Query<CompanyStock>("Usp_AddEditCompany", new
                {
                    @Action = "Delete",
                    @CompanyId = companystock.CompanyId,
                    @CompanyCode = companystock.CompanyCode
                }, commandType: CommandType.StoredProcedure);
            }

        }

        public DateTime  convertdate(long unixDate)
        {
            
            DateTime start = new DateTime(1970, 1, 1, 0, 0, 0, DateTimeKind.Utc);
            DateTime date = start.AddMilliseconds(unixDate).ToLocalTime();
            return date;
        }
    }
    public class CompanyStockResponseModel
    {

        public DateTime date { get; set; }
        public string symbol { get; set; }
        public string companyName { get; set; }
        public string primaryExchange { get; set; }
        public string sector { get; set; }
        public string calculationPrice { get; set; }
        public string open { get; set; }
        public Int64 openTime { get; set; }
        public string close { get; set; }
        public Int64 closeTime { get; set; }
        public string high { get; set; }
        public string low { get; set; }
        public string latestPrice { get; set; }
        public string latestSource { get; set; }
        public string latestTime { get; set; }
        public Int64  latestUpdate { get; set; }
        public string latestVolume { get; set; }
        public string iexRealtimePrice { get; set; }
        public string iexRealtimeSize { get; set; }
        public string iexLastUpdated { get; set; }
        public string delayedPrice { get; set; }
        public Int64 delayedPriceTime { get; set; }
        public string extendedPrice { get; set; }
        public string extendedChange { get; set; }
        public string extendedChangePercent { get; set; }
        public Int64 extendedPriceTime { get; set; }
        public string previousClose { get; set; }
        public string change { get; set; }
        public string changePercent { get; set; }
        public string iexMarketPercent { get; set; }
        public string iexVolume { get; set; }
        public string avgTotalVolume { get; set; }
        public string iexBidPrice { get; set; }
        public string iexBidSize { get; set; }
        public string iexAskPrice { get; set; }
        public string iexAskSize { get; set; }
        public string marketCap { get; set; }
        public string peRatio { get; set; }
        public string week52High { get; set; }
        public string week52Low { get; set; }
        public string ytdChange { get; set; }
        public string startChar { get; set; }
        public string Latestdatetime { get; set; }


    }
    public class CompanyStockHistoricalData
    {
       
        public DateTime date { get; set; }
        public double open { get; set; }
        public double high { get; set; }
        public double low { get; set; }
        public double close { get; set; }
        public int volume { get; set; }
        public int unadjustedVolume { get; set; }
        public double change { get; set; }
        public double changePercent { get; set; }
        public double vwap { get; set; }
        public string label { get; set; }
        public double changeOverTime { get; set; }
        public double AveragePrice { get; set; }


    }
}